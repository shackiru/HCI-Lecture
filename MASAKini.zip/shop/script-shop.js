const category1 = document.getElementById("category-1");
const category2 = document.getElementById("category-2");
const category3 = document.getElementById("category-3");
const cart1 = document.getElementById("cart1");
const cart2 = document.getElementById("cart2");
const cart3 = document.getElementById("cart3");
const cart4 = document.getElementById("cart4");
const cart5 = document.getElementById("cart5");
const cart6 = document.getElementById("cart6");
const cart7 = document.getElementById("cart7");
const cart8 = document.getElementById("cart8");
const cart9 = document.getElementById("cart9");
const cart10 = document.getElementById("cart10");
const cart11 = document.getElementById("cart11");
const cart12 = document.getElementById("cart12");
const cart13 = document.getElementById("cart13");
const cart14 = document.getElementById("cart14");
const cart15 = document.getElementById("cart15");
const yellowcart1 = document.getElementById("yellow-cart1");
const yellowcart2 = document.getElementById("yellow-cart2");
const yellowcart3 = document.getElementById("yellow-cart3");
const yellowcart4 = document.getElementById("yellow-cart4");
const yellowcart5 = document.getElementById("yellow-cart5");
const yellowcart6 = document.getElementById("yellow-cart6");
const yellowcart7 = document.getElementById("yellow-cart7");
const yellowcart8 = document.getElementById("yellow-cart8");
const yellowcart9 = document.getElementById("yellow-cart9");
const yellowcart10 = document.getElementById("yellow-cart10");
const yellowcart11 = document.getElementById("yellow-cart11");
const yellowcart12 = document.getElementById("yellow-cart12");
const yellowcart13 = document.getElementById("yellow-cart13");
const yellowcart14 = document.getElementById("yellow-cart14");
const yellowcart15 = document.getElementById("yellow-cart15");

category1.onclick = function(){
    category1.style.backgroundColor = "#FFD74B";
    category1.style.color = "#FFFFFF";
    category2.style.backgroundColor = "#FFFFFF";
    category2.style.color = "#FFD74B";
    category3.style.backgroundColor = "#FFFFFF";
    category3.style.color = "#FFD74B";
    category1.style.transition = "background-color 0.5s ease, color 0.5s ease";
    category2.style.transition = "background-color 0.5s ease, color 0.5s ease";
    category3.style.transition = "background-color 0.5s ease, color 0.5s ease";
}

category2.onclick = function(){
    category2.style.backgroundColor = "#FFD74B";
    category2.style.color = "#FFFFFF";
    category1.style.backgroundColor = "#FFFFFF";
    category1.style.color = "#FFD74B";
    category3.style.backgroundColor = "#FFFFFF";
    category3.style.color = "#FFD74B";
    category1.style.transition = "background-color 0.5s ease, color 0.5s ease";
    category2.style.transition = "background-color 0.5s ease, color 0.5s ease";
    category3.style.transition = "background-color 0.5s ease, color 0.5s ease";
}

category3.onclick = function(){
    category3.style.backgroundColor = "#FFD74B";
    category3.style.color = "#FFFFFF";
    category2.style.backgroundColor = "#FFFFFF";
    category2.style.color = "#FFD74B";
    category1.style.backgroundColor = "#FFFFFF";
    category1.style.color = "#FFD74B";
    category1.style.transition = "background-color 0.5s ease, color 0.5s ease";
    category2.style.transition = "background-color 0.5s ease, color 0.5s ease";
    category3.style.transition = "background-color 0.5s ease, color 0.5s ease";
}

yellowcart1.onmouseover = function(){
    cart1.style.opacity = "0";
    yellowcart1.style.opacity = "100";
}

yellowcart1.onmouseout = function(){
    cart1.style.opacity = "100";
    yellowcart1.style.opacity = "0";
}

yellowcart2.onmouseover = function(){
    cart2.style.opacity = "0";
    yellowcart2.style.opacity = "100";
}

yellowcart2.onmouseout = function(){
    cart2.style.opacity = "100";
    yellowcart2.style.opacity = "0";
}

yellowcart3.onmouseover = function(){
    cart3.style.opacity = "0";
    yellowcart3.style.opacity = "100";
}

yellowcart3.onmouseout = function(){
    cart3.style.opacity = "100";
    yellowcart3.style.opacity = "0";
}

yellowcart4.onmouseover = function(){
    cart4.style.opacity = "0";
    yellowcart4.style.opacity = "100";
}

yellowcart4.onmouseout = function(){
    cart4.style.opacity = "100";
    yellowcart4.style.opacity = "0";
}

yellowcart5.onmouseover = function(){
    cart5.style.opacity = "0";
    yellowcart5.style.opacity = "100";
}

yellowcart5.onmouseout = function(){
    cart5.style.opacity = "100";
    yellowcart5.style.opacity = "0";
}

yellowcart6.onmouseover = function(){
    cart6.style.opacity = "0";
    yellowcart6.style.opacity = "100";
}

yellowcart6.onmouseout = function(){
    cart6.style.opacity = "100";
    yellowcart6.style.opacity = "0";
}

yellowcart7.onmouseover = function(){
    cart7.style.opacity = "0";
    yellowcart7.style.opacity = "100";
}

yellowcart7.onmouseout = function(){
    cart7.style.opacity = "100";
    yellowcart7.style.opacity = "0";
}

yellowcart8.onmouseover = function(){
    cart8.style.opacity = "0";
    yellowcart8.style.opacity = "100";
}

yellowcart8.onmouseout = function(){
    cart8.style.opacity = "100";
    yellowcart8.style.opacity = "0";
}

yellowcart9.onmouseover = function(){
    cart9.style.opacity = "0";
    yellowcart9.style.opacity = "100";
}

yellowcart9.onmouseout = function(){
    cart9.style.opacity = "100";
    yellowcart9.style.opacity = "0";
}

yellowcart10.onmouseover = function(){
    cart10.style.opacity = "0";
    yellowcart10.style.opacity = "100";
}

yellowcart10.onmouseout = function(){
    cart10.style.opacity = "100";
    yellowcart10.style.opacity = "0";
}

yellowcart11.onmouseover = function(){
    cart11.style.opacity = "0";
    yellowcart11.style.opacity = "100";
}

yellowcart11.onmouseout = function(){
    cart11.style.opacity = "100";
    yellowcart11.style.opacity = "0";
}

yellowcart12.onmouseover = function(){
    cart12.style.opacity = "0";
    yellowcart12.style.opacity = "100";
}

yellowcart12.onmouseout = function(){
    cart12.style.opacity = "100";
    yellowcart12.style.opacity = "0";
}

yellowcart13.onmouseover = function(){
    cart13.style.opacity = "0";
    yellowcart13.style.opacity = "100";
}

yellowcart13.onmouseout = function(){
    cart13.style.opacity = "100";
    yellowcart13.style.opacity = "0";
}

yellowcart14.onmouseover = function(){
    cart14.style.opacity = "0";
    yellowcart14.style.opacity = "100";
}

yellowcart14.onmouseout = function(){
    cart14.style.opacity = "100";
    yellowcart14.style.opacity = "0";
}

yellowcart15.onmouseover = function(){
    cart15.style.opacity = "0";
    yellowcart15.style.opacity = "100";
}

yellowcart15.onmouseout = function(){
    cart15.style.opacity = "100";
    yellowcart15.style.opacity = "0";
}


const food_detail_container = document.getElementById("food-detail-container");
const food_detail = document.getElementById("food-detail");
const food_pop_up = document.getElementById("food-pop-up")
const body = document.getElementsByTagName('body')[0];
let spans1 = document.querySelectorAll('.copy-font-es-kepal-milo span');
let spans2 = document.querySelectorAll('.copy-font-odading span');
let spans3 = document.querySelectorAll('.copy-font-corndog span');
let spans4 = document.querySelectorAll('.copy-font-dalgona-coffee span');
let spans5 = document.querySelectorAll('.copy-font-iced-boba-tea span');
let spans6 = document.querySelectorAll('.copy-font-es-cokelat-cocol span');
let spans7 = document.querySelectorAll('.copy-font-pisang-nugget span');
let spans8 = document.querySelectorAll('.copy-font-indomie-donat span');
let spans9 = document.querySelectorAll('.copy-font-dessert-box span');
let spans10 = document.querySelectorAll('.copy-font-croffle span');
let spans11 = document.querySelectorAll('.copy-font-garlic-bread span');
let spans12 = document.querySelectorAll('.copy-font-salmon-mentai span');
let spans13 = document.querySelectorAll('.copy-font-spaghetti-brulee span');
let spans14 = document.querySelectorAll('.copy-font-bomboloni span');
let spans15 = document.querySelectorAll('.copy-font-mozza-sticks span');

const copy_font_es_kepal_milo = document.getElementById("copy-font-es-kepal-milo");
const copy_font_odading = document.getElementById("copy-font-odading");
const copy_font_corndog = document.getElementById("copy-font-corndog");
const copy_font_dalgona_coffee = document.getElementById("copy-font-dalgona-coffee");
const copy_font_iced_boba_tea = document.getElementById("copy-font-iced-boba-tea");
const copy_font_es_cokelat_cocol = document.getElementById("copy-font-es-cokelat-cocol");
const copy_font_pisang_nugget = document.getElementById("copy-font-pisang-nugget");
const copy_font_indomie_donat = document.getElementById("copy-font-indomie-donat");
const copy_font_dessert_box = document.getElementById("copy-font-dessert-box");
const copy_font_croffle = document.getElementById("copy-font-croffle");
const copy_font_garlic_bread = document.getElementById("copy-font-garlic-bread");
const copy_font_salmon_mentai = document.getElementById("copy-font-salmon-mentai");
const copy_font_spaghetti_brulee = document.getElementById("copy-font-spaghetti-brulee");
const copy_font_bomboloni = document.getElementById("copy-font-bomboloni");
const copy_font_mozza_sticks = document.getElementById("copy-font-mozza-sticks");

const rectangle = document.getElementById("rectangle");
const harga = document.getElementById("harga0");
const yellowcart0 = document.getElementById("yellow-cart0")
const cart0 = document.getElementById("cart0")

yellowcart0.onmouseover = function(){
    cart0.style.opacity = "0";
    yellowcart0.style.opacity = "100";
    cart0.style.transition = "all 0.3s ease";
    yellowcart0.style.transition = "all 0.3s ease";
}


yellowcart0.onmouseout = function(){
    cart0.style.opacity = "100";
    yellowcart0.style.opacity = "0";
    cart0.style.transition = "all 0.3s ease";
    yellowcart0.style.transition = "all 0.3s ease";
}

yellowcart1.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';s
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/es kepal new photo.png")';
    spans1.forEach(span => {
        span.style.opacity = '100';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart2.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/odading.png")';
    harga.innerHTML = "IDR 12,000";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '100';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
    copy_font_odading.style.marginLeft = "14vw";
}

yellowcart3.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/corndog.png")';
    harga.innerHTML = "IDR 15,000";
    copy_font_corndog.style.marginLeft = "14.7vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '100';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart4.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/dalgona coffee.png")';
    harga.innerHTML = "IDR 25,000";
    copy_font_dalgona_coffee.style.marginLeft = "30.5vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '100';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart5.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/iced boba tea.png")';
    harga.innerHTML = "IDR 21,000";
    copy_font_iced_boba_tea.style.marginLeft = "29.5vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '100';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart6.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/es cokelat cocol.png")';
    harga.innerHTML = "IDR 18,000";
    copy_font_es_cokelat_cocol.style.marginLeft = "29.7vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.fontSize = '5vw';
        span.style.opacity = '100';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart7.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/pisang nugget.png")';
    harga.innerHTML = "IDR 20,000";
    copy_font_pisang_nugget.style.marginLeft = "29.2vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.fontSize = '5.6vw';
        span.style.opacity = '100';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart8.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/indomie donat.png")';
    harga.innerHTML = "IDR 12,000";
    copy_font_indomie_donat.style.marginLeft = "29.7vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.fontSize = '5.6vw';
        span.style.opacity = '100';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart9.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/dessert box.png")';
    harga.innerHTML = "IDR 45,000";
    copy_font_dessert_box.style.marginLeft = "21.7vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '100';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart10.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/croffle.png")';
    harga.innerHTML = "IDR 30,000";
    copy_font_croffle.style.marginLeft = "8.3vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '100';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart11.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/garlic bread.png")';
    harga.innerHTML = "IDR 20,000";
    copy_font_garlic_bread.style.marginLeft = "23.8vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '100';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart12.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/salmon mentai.png")';
    harga.innerHTML = "IDR 30,000";
    copy_font_salmon_mentai.style.marginLeft = "30.2vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.fontSize = '5.6vw';
        span.style.opacity = '100';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart13.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/spaghetti brulee.png")';
    harga.innerHTML = "IDR 25,000";
    copy_font_spaghetti_brulee.style.marginLeft = "31vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '100';
        span.style.fontSize = '5.2vw';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart14.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/bomboloni.png")';
    harga.innerHTML = "IDR 25,000";
    copy_font_bomboloni.style.marginLeft = "20.4vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '100';
    });
    spans15.forEach(span => {
        span.style.opacity = '0';
    });
}

yellowcart15.onclick = function(){
    food_detail_container.style.display = 'block';
    body.style.overflow = 'hidden';
    food_detail_container.style.display = "flex";
    rectangle.style.backgroundImage = 'url("/shop/shop_asset/mozza sticks.png")';
    harga.innerHTML = "IDR 25,000";
    copy_font_mozza_sticks.style.marginLeft = "24.2vw";
    spans1.forEach(span => {
        span.style.opacity = '0';
    });
    spans2.forEach(span => {
        span.style.opacity = '0';
    });
    spans3.forEach(span => {
        span.style.opacity = '0';
    });
    spans4.forEach(span => {
        span.style.opacity = '0';
        span.style.fontSize = '5.4vw';
    });
    spans5.forEach(span => {
        span.style.opacity = '0';
    });
    spans6.forEach(span => {
        span.style.opacity = '0';
    });
    spans7.forEach(span => {
        span.style.opacity = '0';
    });
    spans8.forEach(span => {
        span.style.opacity = '0';
    });
    spans9.forEach(span => {
        span.style.opacity = '0';
    });
    spans10.forEach(span => {
        span.style.opacity = '0';
    });
    spans11.forEach(span => {
        span.style.opacity = '0';
    });
    spans12.forEach(span => {
        span.style.opacity = '0';
    });
    spans13.forEach(span => {
        span.style.opacity = '0';
    });
    spans14.forEach(span => {
        span.style.opacity = '0';
    });
    spans15.forEach(span => {
        span.style.opacity = '100';
    });
}


food_detail_container.addEventListener('click', (e) => {
    if (e.target === food_pop_up || food_pop_up.contains(e.target)) {
        return;
    }
    food_detail_container.style.display = "none"
    body.style.overflow = 'auto'; // re-enable scrolling
});

const images = [
  '../shop/shop_asset/slider-1.png',
  '../shop/shop_asset/slider-2.png',
  '../shop/shop_asset/slider-3.png'
];

const slider = document.getElementById('slider-1');
let index = 0;

setInterval(() => {
  index = (index + 1) % images.length;
  const newImage = new Image();
  newImage.src = images[index];
  newImage.onload = () => {
    slider.classList.add('hide');
    setTimeout(() => {
      slider.src = newImage.src;
      slider.classList.remove('hide');
    }, 500);
  };
}, 3000);
